package Renderer;/*

The project produced by:
- David Ben Michael 302518097
- Gadi Bitan

Emails:
1) David Ben Michael: davidbenmi@gmail.com
2) Gadi Bitan:


*/
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import Elements.Light;
import Elements.LightSource;
import Geometries.FlatGeometry;
import Geometries.Geometry;
import Geometries.Sphere;
import javafx.scene.layout.Background;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;
import Scene.Scene;

public class manualTest {
    public static void main(String [] args)
    {
        Ray ray = new Ray(new  Point3D(300,10,-800), new Vector(new Point3D(-10,-20,30)));
        Sphere sp = new Sphere(500, new Point3D(0,0,-1000));
        List<Point3D>lst = new ArrayList<Point3D>(sp.FindIntersections(ray));
        System.out.println(lst.size());
        for (Point3D  p:lst)
              {
            System.out.println(p.toString());
        }
    }


}
