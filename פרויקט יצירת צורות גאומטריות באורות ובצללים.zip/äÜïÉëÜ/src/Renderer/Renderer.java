package Renderer;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import Elements.Light;
import Elements.LightSource;
import Geometries.FlatGeometry;
import Geometries.Geometry;
import javafx.scene.layout.Background;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;
import Scene.Scene;

public class Renderer
{
    private Scene _scene;
    private ImageWriter _imageWriter;
    private final int RECURSION_LEVEL = 3;

    // ***************** Constructors ********************** //

    /**
     *
     * @param imageWriter object of class ImageWriter from this package
     * @param scene object of class Scene from Scene package
     *
     * @meaning: merge the image with the scene
     */
    public Renderer(ImageWriter imageWriter, Scene scene)
    {
        _imageWriter=new ImageWriter(imageWriter);
        _scene=new Scene(scene);
    }
    public void writeToImage()
    {
        _imageWriter.writeToimage();
    }

    // ***************** Operations ******************** //

    /**
     * @meaing: build the image with the geometries shape.
     * The function receive a ray and calculate whether she intersect to geometries shape.
     */
    public void renderImage()
    {
        for (int i = 0; i < _imageWriter.getHeight(); i++)
            for (int j = 0; j < _imageWriter.getWidth(); j++)
            {
                Ray ray=_scene.getCamera().constructRayThroughPixel(_imageWriter.getNx(),
                        _imageWriter.getNy(),j,i,_scene.getScreenDistance(),_imageWriter.getWidth(),_imageWriter.getHeight());

                Entry<Geometry,Point3D>closepoint=findClosesntIntersection(ray);

                if(closepoint==null)
                    _imageWriter.writePixel(j,i, _scene.getBackground());
                else
                    _imageWriter.writePixel(j,i,calcColor(closepoint.getKey(),closepoint.getValue(),ray));

            }
    }

    /**
     *
     * @param ray :  a ray from the camera eye.
     * @return a Entry with one point: the closest intersection point to the camera eye from all all the geometries shape.
     */
    private Entry<Geometry, Point3D> findClosesntIntersection(Ray ray)
    {
        Entry<Geometry,Point3D>entry;
        Map<Geometry,List<Point3D>>intersection=getSceneRayIntersections(ray);
        Map<Geometry,Point3D>closepoint=getClosestPoint(intersection);
        if(closepoint.size()==0) {
            return null;
        }
        entry=closepoint.entrySet().iterator().next();
        return entry;
    }

    /**
     *
     * @param interval: the interval of the pixels
     * @meaning: the function print a coordinate gird in the image.
     */
    public void printGrid(int interval)
    {
        for (int i = 0; i < _imageWriter.getHeight(); i++)
            for (int j = 0; j < _imageWriter.getWidth(); j++)
                if (i % interval == 0 || j % interval == 0)
                    _imageWriter.writePixel(j, i, 255, 255, 255);
        writeToImage();

    }

    /**
     *
     * @param light- a kind of light source
     * @param point - a point of the geometry
     * @param geometry -
     * @return - boolean value
     * @meanimg : the function create "shadows ray" from the intersection point to the source of light.
     * if there are intersection points with the shadows ray and the geometries at the scene-  that mean the points
     *  are occluded. the occluded points inserted into  a map - if the map is empty (no occluded point) we return false value,
     *  otherwise - we return true value.
     */
    private boolean occluded(LightSource light, Point3D point, Geometry geometry) {
        Vector lightDirection = light.getL(point);
        //lightDirection.normalize();
        lightDirection.scale(-1);

        Point3D geometryPoint = new Point3D(point);
        Vector epsVector = new Vector(geometry.getNormal(point));
        //epsVector.normalize();
        epsVector.scale(2);

        geometryPoint.add(epsVector);
        Ray lightRay = new Ray(geometryPoint, lightDirection);

        Map<Geometry, List<Point3D>> intersectionPoints = getSceneRayIntersections(lightRay);

        if (geometry instanceof FlatGeometry)
            intersectionPoints.remove(geometry);

        return !intersectionPoints.isEmpty();
    }


    /**
     *
     * @param// ks- distance factor
     * @param// V - the "eye of the camera"
     * @param //N - normal to the point of the geometry
     * @param// L - vector from the source of the light to the point of the geometry
     * @param //nSh -shininess
     * @param// intensity- intensity of the light on the point
     * @return - specular color
     * @meaning: computing vector R (reflection on the point)  according to the formula, and return specular light
     * according to Phong formula
     */
    private Color calcSpecularComp(double Ks, Vector V, Vector N, Vector L, double n, Color color)  {
        L.normalize();
        N.normalize();
        double x = 2 * L.dotProduct(N);
        Vector _normal = new Vector(N);
        _normal.scale(x);
        Vector R = new Vector(L.getHead(), _normal.getHead());
        R.normalize();
        V.normalize();
        double rgb = V.dotProduct(R);
       /* if (V.dotProduct(R) > 0) {
            return Color.BLACK;
        }*/
        rgb = Math.abs(rgb);
        rgb = Math.pow(rgb, n);
        rgb *= Ks;
        return CheckBoundaryOfColor((int) (color.getRed() * rgb),
                (int) (color.getGreen() * rgb),
                (int) (color.getBlue() * rgb));
    }

    /**
     *
     * @param// kd-distance factor
     * @param// normal -normal to the point of the geometry
     * @param L - vector from the source of the light to the point of the geometry
     * @param// intensity- intensity of the light on the point
     * @return - diffuse color
     */
    private Color calcDiffusiveComp(double Kd, Vector N, Vector L, Color color)  {
        L.normalize();
        N.normalize();
        Vector N_L = new Vector(N);
        double z = Kd * Math.abs(N_L.dotProduct(L));

        return CheckBoundaryOfColor((int) (color.getRed() * z),
                (int) (color.getGreen() * z),
                (int) (color.getBlue() * z));
    }





    /**
     *
     * @param geometry : shape of geometry
     * @param point : intersection point
     * @param ray: a ray from the camera eye.
     * @return color of a specific point on the geometry shape
     *
     * @meaning: the function paint a intersection point of geometry with the ray by the
     * calling the function addColors. The arguments of addColors are the the intensity of the
     * Light and the emmission  of the light. (parameters of Color type).
     */
    private Color calcColor(Geometry geometry, Point3D point, Ray ray) {

    Color ambientLight = _scene.getAmbientLight().getIntensity();
    Color emissionLight = geometry.getEmmission();
    Iterator<LightSource> lights = _scene.getLightsIterator();
    Color diffuseLight = new Color(0, 0, 0);
    Color specularLight = new Color(0, 0, 0);
        while (lights.hasNext()) {
            LightSource light = lights.next();
            if (!occluded(light, point, geometry)) {
                Color TempDiffuseLight = calcDiffusiveComp(geometry.getMaterial().getKd(),
                        geometry.getNormal(point),
                        light.getL(point),
                        light.getIntensity(point));
                diffuseLight = CheckBoundaryOfColor((diffuseLight.getRed() + TempDiffuseLight.getRed()),
                        (diffuseLight.getGreen() + TempDiffuseLight.getGreen()),
                        (diffuseLight.getBlue() + TempDiffuseLight.getBlue()));

                Color TempSpecularLight = calcSpecularComp(geometry.getMaterial().getKs(),
                        new Vector(point, _scene.getCamera().getP0()),
                        geometry.getNormal(point),
                        light.getL(point),
                        geometry.getShininess(),
                        light.getIntensity(point));
                specularLight = CheckBoundaryOfColor((specularLight.getRed() + TempSpecularLight.getRed()),
                        (specularLight.getGreen() + TempSpecularLight.getGreen()),
                        (specularLight.getBlue() + TempSpecularLight.getBlue()));

            }
        }

        return CheckBoundaryOfColor(
                ambientLight.getRed() + emissionLight.getRed() + diffuseLight.getRed() + specularLight.getRed() ,
                ambientLight.getGreen() + emissionLight.getGreen() + diffuseLight.getGreen() + specularLight.getGreen()  ,
                ambientLight.getBlue() + emissionLight.getBlue() + diffuseLight.getBlue() + specularLight.getBlue() ) ;
    }



    /**
     *
     * @param: Map of geometries and their  intersectionPoints
     * @return: Map of geometries and only one intersectionPoint for each geometry
     *
     * @meaning The function  receive a map of geometries and return a map with
     * the closest intersection point to the camera eye, for each geometry.
     */

    private Map<Geometry, Point3D> getClosestPoint(Map<Geometry,
            List<Point3D>> intersectionPoints)
    {
        double distance=Double.MAX_VALUE;
        Point3D P0=_scene.getCamera().getP0();
        Map<Geometry, Point3D>minDistancePoint=new HashMap<Geometry,Point3D>();//min point per geometry
        for(Entry<Geometry,List<Point3D>>entry:intersectionPoints.entrySet())//loop on the big map
        {
            for(Point3D point:entry.getValue())//loop on spetipic geometry
            {
                double distancePoint=P0.distance(point);
                if(distancePoint<distance)
                {
                    minDistancePoint.clear();
                    minDistancePoint.put(entry.getKey(), new Point3D(point));
                    distance = distancePoint;

                }
            }

        }
        return minDistancePoint;




    }

    /**
     *
     * @param: ray: a ray from the camera eye.
     * @return: map  that consists of a field of geometry and a field of intersection points with the same geometry
     *
     * @meaning: The function receives a ray and returns the intersection points of the ray with each  geometry in the scene.
     */
    private Map<Geometry, List<Point3D>> getSceneRayIntersections(Ray ray)
    {
        Iterator<Geometry>geometries=_scene.getGeometriesIterator();
        Map<Geometry,List<Point3D>>map=new HashMap<Geometry,List<Point3D>>();
        while (geometries.hasNext())
        {
            Geometry geometry=geometries.next();
            List<Point3D>geometryIntersectionPoint=geometry.FindIntersections(ray);
            if (!geometryIntersectionPoint.isEmpty())
                map.put(geometry,geometryIntersectionPoint);

        }
        return  map;
    }



    private Color CheckBoundaryOfColor(double r, double g, double b) {
        if (r > 255) {
            r = 255;
        }
        if (g > 255) {
            g = 255;
        }
        if (b > 255) {
            b = 255;
        }
        if (r < 0) {
            r = 0;
        }
        if (g < 0) {
            g = 0;
        }
        if (b < 0) {
            b = 0;
        }
        return new Color((int) r, (int) g, (int) b);
    }


    /**
     *
     * @param: color a (A field representing color)
     * @param: color b (A field representing color)
     * @return color
     * @meaning The function takes two colors  and creates a new color
     */
    private Color addColors(Color a , Color b)//add color according to the data
    {
        int R=a.getRed()+b.getRed();
        if(R>255)R=R%255;
        int G=a.getGreen()+b.getGreen();
        if(G>255)G=G%255;
        int B=a.getBlue()+b.getBlue();
        if(B>255)B=B%255;
        return new Color(R,G,B);



    }

}
