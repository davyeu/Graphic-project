package primitives;

public class Point3D extends Point2D
{
    protected Coordinate z;

    // ***************** Constructors ********************** //
    public Point3D() {
        z = new Coordinate();
    }

    public Point3D(Coordinate x, Coordinate y, Coordinate z) {
        super(x, y);
        z = new Coordinate(z);
    }

    public Point3D(double _x, double _y, double _z) {
        super(new Coordinate(_x), new Coordinate(_y));
        z = new Coordinate(_z);
    }

    public Point3D(Point3D p3) {
        super(p3.getX(), p3.getY());
        z = p3.getZ();
    }

    // ***************** Getters/Setters ********************** //
    public Coordinate getZ() {
        return new Coordinate(z);
    }

    public void setZ(Coordinate _z) {
        z=_z;
    }

    // ***************** Administration	******************** //
    @Override
    public String toString()
    {
        return "("+x.getCoordinate()+","+y.getCoordinate()
                +","+z.getCoordinate()+")";
    }

    public int compareTo(Point3D op3)
    {
        if(((Point2D) this).compareTo((Point2D)op3)==0)
            if(this.getZ().compareTo(op3.getZ())==0)
                return 0;
        return 1;
    }

    // ***************** Operations ******************** //
    public void add(Vector vec)
    {
        x.add(vec.getHead().getX());
        y.add(vec.getHead().getY());
        z.add(vec.getHead().getZ());
    }
    public void subtract(Vector vec)
    {
        this.x.subtract(vec.getHead().getX());
        this.y.subtract(vec.getHead().getY());
        this.z.subtract(vec.getHead().getZ());
    }
    public double distance(Point3D point) {
        return Math.sqrt(Math.pow(this.x.getCoordinate() - point.getX().getCoordinate(), 2) +
                Math.pow(this.y.getCoordinate() - point.getY().getCoordinate(), 2) +
                Math.pow(this.z.getCoordinate() - point.getZ().getCoordinate(), 2));
    }

}

