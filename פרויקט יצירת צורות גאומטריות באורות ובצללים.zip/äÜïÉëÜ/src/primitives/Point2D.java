package primitives;

public class Point2D implements Comparable<Point2D> {
    protected Coordinate x ;
    protected Coordinate y;

    // ***************** Constructors ********************** //
    public Point2D() {
        x = new Coordinate();
        y = new Coordinate();

    }
    public Point2D(Coordinate _x, Coordinate _y)
    {
        x = new Coordinate(_x);
        y = new Coordinate(_y);
    }

    public Point2D(Point2D p2) {
        this.x = p2.x;
        this.y = p2.y;
    }

    // ***************** Getters/Setters ********************** //
    public void setX(Coordinate _x) {
        this.x = _x;
    }

    public void setY(Coordinate _y) {
        this.y = _y;
    }

    public Coordinate getX() {
        return x;
    }

    public Coordinate getY() {
        return y;
    }

    // ***************** Administration	******************** //
    @Override
    public int compareTo(Point2D op2) {
        if (this.x.compareTo(op2.x) == 0 && this.y.compareTo(op2.y) == 0)
            return 0;
        return 1;
    }

}
