package primitives;

public class Vector implements Comparable<Vector>
{
    protected Point3D head;

    // ***************** Constructors ********************** //
    public Vector()
    {
        head=new Point3D();
    }
    public Vector(Point3D he)
    {
        head=new Point3D(he);
    }
    public Vector(Vector vec)
    {
        head=vec.getHead();
    }
    public Vector(double xHead,double yHead,double zHead)
    {
        this.head =new Point3D(xHead,yHead,zHead);
    }

    public Vector(Point3D p1, Point3D p2) {//q

        this(p2.getX().getCoordinate() - p1.getX().getCoordinate(),
                p2.getY().getCoordinate() - p1.getY().getCoordinate(),
                p2.getZ().getCoordinate() - p1.getZ().getCoordinate());

    }

    // ***************** Getters/Setters ********************** //
    public Point3D getHead()
    {
        return new Point3D(head);
    }
    public void setHead(Point3D he)
    {
        head=new Point3D(he);
    }

    // ***************** Administration	******************** //
    @Override
    public int compareTo(Vector vec) {
        return this.head.compareTo(new Point3D(vec.head));
    }//q
    @Override
    public String toString() {
        return head.toString();
    }

    // ***************** Operations ******************** //
    public void add (Vector vec)
    {
        this.head.add(vec);
    }
    public void subtract(Vector vec) {
        this.head.subtract(vec);
    }

    public void scale(double scalar)// multiply the vector by Scalar
    {
        head.setX(new Coordinate(scalar*head.getX().getCoordinate()));
        head.setY(new Coordinate(scalar*head.getY().getCoordinate()));
        head.setZ(new Coordinate(scalar*head.getZ().getCoordinate()));
    }
    public Vector crossProduct(Vector vector)
    {
        double a1=head.getX().getCoordinate();
        double a2=head.getY().getCoordinate();
        double a3=head.getZ().getCoordinate();

        double b1=vector.head.getX().getCoordinate();
        double b2=vector.head.getY().getCoordinate();
        double b3=vector.head.getZ().getCoordinate();

        return  new Vector(a2*b3-a3*b2,a3*b1-a1*b3,a1*b2-a2*b1);

    }
    public double length()
    {
        return Math.sqrt(Math.pow(head.getX().getCoordinate(),2)+Math.pow(head.getY().getCoordinate(),2)
                +Math.pow(head.getZ().getCoordinate(),2));

    }
    public void normalize() //changing the vector lenght to "1" , without changing his direction.
    {
        if (length() == 0)
            throw new ArithmeticException();
        double x = this.head.getX().getCoordinate();
        double y = this.head.getY().getCoordinate();
        double z = this.head.getZ().getCoordinate();

        double length = this.length();

        this.setHead(new Point3D(x/length,
                y/length,
                z/length));
    }
    public double dotProduct(Vector vector)
    {
        double a1=head.getX().getCoordinate();
        double a2=head.getY().getCoordinate();
        double a3=head.getZ().getCoordinate();

        double b1=vector.head.getX().getCoordinate();
        double b2=vector.head.getY().getCoordinate();
        double b3=vector.head.getZ().getCoordinate();

        return a1*b1+a2*b2+a3*b3;

    }
}




