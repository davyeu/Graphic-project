package primitives;

public class Coordinate implements Comparable<Coordinate>
{
    protected double Coordinate;

    // ***************** Constructors ********************** //
    public Coordinate() {this.Coordinate=0.0;}
    public Coordinate(double cordy){this.Coordinate=cordy;}
    public Coordinate (Coordinate cordy){this.Coordinate= cordy.Coordinate;}

    // ***************** Getters/Setters ********************** //
    public double getCoordinate()
    {
        return Coordinate;
    }
    public void setCoordinate(double coordinate) {
        this.Coordinate = coordinate;
    }
    @Override

    // ***************** Administration	******************** //
    public int  compareTo(Coordinate cordy){return Double.compare(this.Coordinate , cordy.Coordinate);}

    // ***************** Operations ******************** //
    public void add (Coordinate cordy)
    {
        this.Coordinate+=cordy.Coordinate;
    }
    public void subtract(Coordinate cordy)
    {
        this.Coordinate-=cordy.Coordinate;
    }

}
