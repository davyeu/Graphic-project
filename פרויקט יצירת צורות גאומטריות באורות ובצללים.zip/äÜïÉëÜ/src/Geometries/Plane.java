package Geometries;

import primitives.Point3D;
import primitives.Vector;
import primitives.Ray;

import java.util.ArrayList;
import java.util.List;


public  class Plane extends FlatGeometry  {

    private Vector _normal;
    private Point3D _Q;

    // ***************** Constructors ********************** //


    public Plane (Plane plane)
    {
        _normal=   new Vector(plane.getNormal(null));
        _Q= new Point3D(plane.getQ());
    }
    public Plane (Vector normal, Point3D q)
    {
        _normal= new Vector(normal);
        _Q= new Point3D(q);
    }

    // ***************** Getters/Setters **********************

    public Vector getNormal(Point3D point)
    {
        return new Vector(_normal);
    }
    public Point3D getQ()
    {
        return new Point3D(_Q);
    }
    public void setNormal(Vector normal)
    {
        _normal=normal;
    }
    public void setQ(Point3D d)
    {
        _Q=d;
    }

    // ***************** Operations ********************

    /**
     *
     * @Paremeter: ray- the ray is computed at "constructRayThroughPixel" at Camera class.
     * @Return Value: List of Point3D that include the intersection point of the ray on the plane.
     * If there is no intersection point, then the function return empty list.
     * @Meaning: the function compute whether the ray intersect the plane. If there is intersection point, the point
     * is adding to the list.
     * @See Also: The same functions at the other geometries shapes at this package.
     */
    @Override
    public List<Point3D> FindIntersections(Ray ray)
    {
        ArrayList<Point3D> list =new ArrayList<Point3D>();
        Point3D P0= new Point3D(ray.getPoo()); // the starting point of the ray
        Vector tempVec= new Vector(_Q,P0); //  this vector necessary  to computing below
        Vector Direction= new Vector(ray.getDirection()); // the Direction of the ray
        double temp1=_normal.dotProduct(tempVec);
        double temp2=_normal.dotProduct(Direction);
        double t;

        t= (temp1/temp2); // t- is the scalar of the ray)
        t=t*-1;

        if (t>=0){ // that mean the ray is intersect with the plane
            Direction.scale(t);
            P0.add(Direction);
            list.add(P0);
            return (list);
        }
        else
        {
            ArrayList<Point3D> Emptylist = new ArrayList<Point3D>();
            return Emptylist;
        }
    }

}
