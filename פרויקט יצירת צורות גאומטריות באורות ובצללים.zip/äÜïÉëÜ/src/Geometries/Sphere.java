package Geometries;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

import java.util.ArrayList;
import java.util.List;

public class Sphere extends RadialGeometry {

    private Point3D _center;

    // ***************** Constructors **********************

    public Sphere (Sphere sphere)
    {
        _center=  sphere.getCenter();
        _radius=sphere.getRadius();
    }
    public Sphere(double radius, Point3D center)
    {
        _center= center;
        _radius=radius;
    }


    // ***************** Getters/Setters **********************
    public Point3D getCenter()
    {
        return  new Point3D(_center);
    }
    public void setCenter(Point3D center)
    {
        _center=center;
    }

    // ***************** Operations ********************

    /**
     *
     * @param ray- the ray is computed at "constructRayThroughPixel" at Camera class.
     * @Return Value: List of Point3D that include the intersection points of the ray on the Sphere.
     * If there is no intersection points, then the function return empty list.
     * @Meaning: the function compute whether the ray intersect the sphere. If there are intersection points, the points
     * are adding to the list.
     * There are two options of intersection:
     * 1) the origin of the ray is in the sphere and she intersect him only once
     * 2) the origin of the ray is outside the sphere and she intersect him twice.
     * @See Also: The same functions at the other geometries shapes at this package.
     */


    @Override
    public List<Point3D> FindIntersections(Ray ray)
    {
        ArrayList<Point3D> list= new ArrayList<Point3D>();
        ArrayList<Point3D> Emptylist= new ArrayList<Point3D>();
        Vector L= new Vector(ray.getPoo(),_center); // the vector from the "camera eye" to the center of the sphere.
        Vector V= new Vector(ray.getDirection());
        V.normalize();
        double Tm = L.dotProduct(V); // Tm- is the  projection`s length of vertical line  on Vector V
        if (_radius>L.length()) { // that mean the origin of the ray is in the sphere and she intersect him only once
            V.scale(Tm);
            Point3D P= new Point3D(V.getHead()); // P is close to the real intersect point
            list.add(P);
            return list;

        }

        //  "d" -  vertical Line from the center of the sphere to vector V
        double tmp= Math.pow(L.length(),2);
        double d= Math.sqrt(tmp- Math.pow(Tm,2)); // calculating d by Pitagurs formula
        if (d>_radius) // that mean the ray do not intersect the sphere
            return Emptylist;

        double Th = Math.sqrt(Math.pow(_radius,2)- Math.pow(d,2)); // calculating Th by Pitaguras formula
        // t1 and t2 is the scales of vector V : t1*V return first intersection(P1) , t2*V return second intersection(P2)
        double t1= Tm-Th;
        double t2= Tm +Th;
        if (t1>=0)
        {
            Vector tmp1= new Vector(V);
            Vector tmp2= new Vector(V);
            tmp1.scale(t1);
            Point3D P1= new Point3D(tmp1.getHead()); // first intersection with the sphere
            tmp2.scale(t2);
            Point3D P2= new Point3D(tmp2.getHead()); // second  intersection with the sphere
            list.add(P1);
            list.add(P2);
            return list;
        }
        else
        {
            return Emptylist;
        }


    }

    public Vector getNormal(Point3D point)
    {
        Vector vec= new Vector(_center,point);
        vec.normalize();
        return  vec;
    }

}
