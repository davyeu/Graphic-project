package Geometries;


public abstract class RadialGeometry extends Geometry {

    protected double _radius;

    public  RadialGeometry(){

    }
    public   RadialGeometry(double radius)
    {
        _radius=radius;
    }

    public  double getRadius()
    {
        return _radius;
    }
    public  void setRadius(double radius)
    {
        _radius=radius;
    }
}
