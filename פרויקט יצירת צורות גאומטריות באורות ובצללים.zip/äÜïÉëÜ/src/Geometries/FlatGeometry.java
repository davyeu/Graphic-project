package Geometries;


public abstract class FlatGeometry extends Geometry {


    
}
