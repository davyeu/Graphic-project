package Geometries;

import primitives.Point3D;
import primitives.Vector;
import primitives.Ray;

import java.util.ArrayList;
import java.util.List;

public  class Triangle extends FlatGeometry  {
    private Point3D _p1;
    private Point3D _p2;
    private Point3D _p3;

    // ***************** Constructors ********************** //

    public Triangle()
    {
        _p1=new Point3D(1,0,0);
        _p2= new Point3D(0,1,0);
        _p3 = new Point3D(1,1,1);
    }
    public Triangle(Triangle triangle)
    {
        _p1=  new Point3D(triangle.getP1());
        _p2 = new Point3D(triangle.getP2());
        _p3= new Point3D(triangle.getP3());
    }
    public Triangle(Point3D p1, Point3D p2, Point3D p3){
        _p1= new Point3D(p1.getX().getCoordinate(),p1.getY().getCoordinate(),p1.getZ().getCoordinate());
        _p2= new Point3D(p2.getX().getCoordinate(),p2.getY().getCoordinate(),p2.getZ().getCoordinate());
        _p3= new Point3D(p3.getX().getCoordinate(),p3.getY().getCoordinate(),p3.getZ().getCoordinate());
    }


    // ***************** Getters/Setters ********************** //

    public Point3D getP1() { return _p1;}
    public Point3D getP2() {return _p2;}
    public Point3D getP3() {return _p3;}

    public void setP1(Point3D p1) {
        _p1=p1;
    }
    public void setP2(Point3D p2) {
        _p2= p2;
    }
    public void setP3(Point3D p3){
        _p3= p3;
    }

    // ***************** Operations ********************

    /**
     *
     * @param point- one  of the points of the vertex of the triangle
     * @return: The normal to the triangle.
     */
    public Vector getNormal(Point3D point){

        Vector T1= new Vector(_p1,_p2);
        Vector T2 = new Vector(_p1,_p3);
        Vector Cross= new Vector(T1.crossProduct(T2));
        Cross.normalize();
        Cross.scale(-1);

        return Cross;

    }

    /**
     *
     * @param ray- the ray is computed at "constructRayThroughPixel" at Camera class.
     * @Return Value: List of Point3D that include the intersection point of the ray on the triangle.
     * If there is no intersection point, then the function return empty list.
     * @Meaning: the function compute whether the ray intersect the triangle. If there is intersection point, the point
     * is adding to the list.
     * @See Also: The same functions at the other geometries shapes at this package.
     */
    public List<Point3D> FindIntersections(Ray ray)
    {
        ArrayList<Point3D> list =new ArrayList<Point3D>();
        ArrayList<Point3D> Emptylist= new ArrayList<Point3D>();
        ArrayList<Point3D> tempList= new ArrayList<Point3D>();

        //primary checking: checking whether the ray has intersected the plane that the triangle is include him.

        Point3D _P0= ray.getPoo(); // the starting point of the ray
        Vector N= this.getNormal(null); // receive the normal to the triangle
        Plane plane = new Plane(N,getP3()); // If the ray is intersect the triangle, then she intersect this plane
        if (plane.FindIntersections(ray).size()==0) // if the ray does not intersect the plane
            return Emptylist;

        Vector intersectionPoint= new Vector(_P0,plane.FindIntersections(ray).get(0)); //get(0): return the intersection point at plane above

        //We computing the three vectors from the point of the triangle to "P0".
        Vector V1= new Vector (_P0,_p1);
        Vector V2= new Vector (_P0,_p2);
        Vector V3= new Vector (_P0,_p3);

        //Then we found their normals and normalize them
        Vector N1=new Vector(V1.crossProduct(V2));
        Vector N2= new Vector (V2.crossProduct(V3));
        Vector N3 =new Vector (V3.crossProduct(V1));
        N1.normalize();
        N2.normalize();
        N3.normalize();

        // At this step we calculate dot Product between intersection Vector and the normals

        double s1= N1.dotProduct(intersectionPoint);
        double s2= N2.dotProduct(intersectionPoint);
        double s3= N3.dotProduct(intersectionPoint);
        if (s1!=0)
            s1=s1*-1;
        if (s2!=0)
            s2=s2*-1;
        if (s3!=0)
            s3=s3*-1;

        // If all S (s1,s2,s3) have the same sign number (positive or negative) - the ray intersect the triangle
        if ((s1*s2>0) && (s1*s3>0) && (s2*s3>0))
        {
            list.add(plane.FindIntersections(ray).get(0));
            return list;
        }
        else
        {
            return Emptylist;
        }
    }

}
