package Scene;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import Elements.AmbientLight;
import Elements.Camera;
import Elements.LightSource;
import Geometries.Geometry;
import javafx.scene.layout.Background;

public class Scene {
    private Color _background;
    public AmbientLight _ambientLight;
    private List<Geometry> _geometries = new ArrayList<Geometry>();
    private Camera _camera;
    private double _screenDistance;
    private List<LightSource> _lights = new ArrayList<LightSource>();
    private String _sceneName = "scene";

    // ***************** Constructors ********************** //

    /**
     * @background: the color of the background of the picture.
     * @ambientLight: build a default ctor of the class ambientLight from Elements package.
     * @camera: build a default ctor o f the class ambientLight from Elements package.
     * @screenDistance: the distance from the view plane to the eye of the camera
     *
     * @meaing: the function build the scene of the picture, at this default ctor there are no geometries.
     */
    public Scene() {
        _background = new Color(0, 0, 0);
        _ambientLight = new AmbientLight();
        _camera = new Camera();
        _screenDistance = 150.00;
    }

    public Scene(Scene scene) {
        _background = scene.getBackground();
        _ambientLight = scene.getAmbientLight();
        _camera = scene.getCamera();
        _screenDistance = scene._screenDistance;
        _geometries = scene._geometries;
        _lights = scene._lights;

    }

    public Scene(AmbientLight aLight, Color background,
                 Camera camera, double screenDistance) {
        _ambientLight = new AmbientLight(aLight);
        _background = background;
        _camera = (new Camera(camera));
        _screenDistance = screenDistance;

    }

    // ***************** Getters/Setters ********************** //

    public Color getBackground() {
        return _background;
    }

    public AmbientLight getAmbientLight() {
        return new AmbientLight(_ambientLight);
    }

    public Camera getCamera() {
        return new Camera(_camera);
    }

    public String getSceneName() {
        return _sceneName;
    }

    public double getScreenDistance() {
        return _screenDistance;
    }

    public void setBackground(Color background) {
        this._background = background;
    }

    public void setAmbientLight(AmbientLight ambientLight) {
        _ambientLight = ambientLight;
    }

    public void setCamera(Camera camera) {
        _camera = camera;
    }

    public void setSceneName(String sceneNAme) {
        _sceneName = sceneNAme;
    }

    public void setScreenDistance(double screenDistance) {
        _screenDistance = screenDistance;
    }


    // ***************** Operations ******************** //

    /**
     *
     * @param geometry: a shape from the Geometries package .
     *
     * @meaning: adding a shape to list that include at the scene
     */
    public void addGeometry(Geometry geometry)
    {
        _geometries.add(geometry);

    }

    public Iterator<Geometry> getGeometriesIterator()
    {
        return _geometries.iterator();
    }

    public void addLight(LightSource light)
    {
        _lights.add(light);

    }
    public Iterator<LightSource> getLightsIterator()
    {
        return _lights.iterator();
    }




}

