package Elements;

import primitives.Point3D;
import primitives.Vector;
import primitives.Ray;
import java.util.Map;

public class Camera {

    //Eye point of the camera
    private Point3D _P0;

    private Vector _vUp;
    private Vector _vTo; // vector toward
    private Vector _vRight;

    // ***************** Constructors ********************** //

    /**
     * @_P0: the point that from her the vectors of the camera sent.
     * @_vUp: vector up is vertical to _vTo
     * @_vTo: vector toward sent to the view plane
     * @_Vright: the cross product of vUp and vTo
     */
    public Camera() {
        _P0 = new Point3D(0, 0, 0);
        _vUp = new Vector(0.0, 1.0, 0.0);
        _vTo = new Vector(0.0, 0.0, -1.0);

        _vRight = _vUp.crossProduct(_vTo);
    }

    public Camera(Camera camera) {
        _P0 = camera.getP0();
        _vUp = camera.get_vUp();
        _vTo = camera.get_vTo();
        _vRight = camera.get_vRight();

    }


    public Camera(Point3D P0, Vector vUp, Vector vTo) {
        _P0 = new Point3D(P0);
        _vUp = new Vector(vUp);
        _vUp.normalize();
        _vTo = new Vector(vTo);
        _vTo.normalize();
        _vRight = _vUp.crossProduct(_vTo);
        _vRight.normalize();
    }


// ***************** Getters/Setters ********************** //

    public Vector get_vUp() {
        return new Vector(_vUp);
    }

    public void set_vUp(Vector vUp) {
        _vUp = vUp;
    }

    public Vector get_vTo() {
        return new Vector(_vTo);
    }

    public void set_vTo(Vector vTo) {
        _vTo = vTo;
    }

    public Point3D getP0() {
        return new Point3D(_P0);
    }

    public void setP0(Point3D P0) {
        _P0 = P0;
    }

    public Vector get_vRight() {
        return new Vector(_vRight);
    }

    // ***************** Administration ********************** //

    public String toString() {
        return "Vto: " + _vTo + "\n" + "Vup: " + _vUp + "\n" + "VRight:" + _vRight + ".";
    }

    // ***************** Operations ******************** //

    /**
     * @param Nx-          number of the pixels at coordinate x
     * @param Ny-          number of the pixels at coordinate y
     * @param i-           index at two dimensional array.
     * @param j            -index at two dimensional array.
     * @param screenDist   - scalar that multiply _vTo . the multiplication of "screenDist" and "_vTo" return the the center point at the screen plane
     * @param screenWidth- the width of the screen plane.
     * @param screenHeight - the height of the screen plane.
     * @Return Value: ray that intersect the view plane.
     * @Meaning: The function receive the parameters of the view plane.
     * Then the function calculating the specific pixel that ray intersect the plane,
     * each pixel present different color.
     * Finally the function return the direction of the ray.
     */
    public Ray constructRayThroughPixel (int Nx, int Ny, double i, double j, double screenDist,
                                         double screenWidth, double screenHeight)
    {
        // find Pc: the center point at the view plane
        Vector Vc= new Vector(_vTo);
        Vc.scale(screenDist);
        Point3D Pc= new Point3D();
        Pc.add(Vc);

        // calculate Ratio of the height and width to the number of pixels.
        double Rx= screenWidth/Nx;
        double Ry= screenHeight/Ny;

        /* find the point P[i,j]= the intersection point of the ray at the view plane
         to find P[i,j] we using Elishai's slide formula (for more information see
         the explain at the project documation*/
        double scale1=(i-((Nx+1)/2))*Rx  ;
        double scale2= (j-((Ny+1)/2))*Ry ;
        Vector vRight= new Vector(_vRight);
        Vector vUp= new Vector (_vUp);
        vRight.scale(scale1);
        vUp.scale(scale2);
        vRight.subtract(vUp);
        Point3D Pij= new Point3D(Pc);
        Pij.add(vRight);

        // The final step: find the ray that intersect the view plane at P[i,j}
        Vector Vij= new Vector(Pij);
        Vector V0= new Vector();
        Vij.subtract(V0);

        Point3D screenPoint=new Point3D();
        screenPoint.add(_vTo);// this the point that vector -vTo intersect the view plane

        Ray Rij= new Ray(screenPoint,Vij);

        return Rij;

    }
}


