package Elements;

import primitives.Point3D;
import primitives.Vector;

import java.awt.*;

public class SpotLight  extends PointLight{

    private Vector _direction;

    // ***************** Constructor **********************

    /**
     *
     * @param color- the source of light (namely r.g.b color)
     * @param position- another source of light (not the mainly source) that illuminate from this point.
     * @param direction- the direction of the spot light
     * @param kc- decreased factor
     * @param kl -decreased factor
     * @param kq -decreased factor
     */
     public SpotLight(Color color, Point3D position, Vector direction, double kc, double kl, double kq)
     {
         super(color,position,kc,kl,kq);
         _direction=direction;

     }

    // ***************** Getters/Setters ********************** //

    /**
     *
     * @param point - a point of the geometry shape
     * @return - the color of the point - the intensity of the color is impact by the angle
     * between the secondary source of light direction and the vector that hit the geometry shape.
     */
    @Override
     public Color getIntensity(Point3D point)
    {

        Color pointColor = super.getIntensity(point);

        Vector l = getL(point);
        l.normalize();

        double k = Math.abs(_direction.dotProduct(l));

        if (k > 1) k = 1; // doesn't allow light magnification

        return new Color((int)(pointColor.getRed()   * k),
                (int)(pointColor.getGreen() * k),
                (int)(pointColor.getBlue()  * k));
    }
}
