package Elements;
import primitives.Point3D;
import primitives.Vector;

import java.awt.Color;

public   class  AmbientLight extends Light
{
    /**
     * _Ka: a constant that multiply the color in order to determine the intensity of color
     */
    private final double _Ka = 0.1;

    // ***************** Constructors ********************** //

    public AmbientLight()
    {
        super (new Color(255,255,255));
    }
    public AmbientLight(AmbientLight aLight)
    {
        super (aLight._color);

    }

    /**
     *
     * @param r: the color red
     * @param g : the color green
     * @param b: the color blue
     *
     * @meaning: by this three colors we can paint all the colors.
     */
    public AmbientLight(int r, int g, int b)
    {
        super(new Color(r, g, b));

    }

    // ***************** Getters/Setters ********************** //

    public Color getColor()
    {
        return _color;
    }
    public void setColor(Color color)
    {
        _color=color;
    }
    public double getKa()
    {
        return _Ka;
    }

    @Override
    public Color getIntensity(Point3D point) {
        return getIntensity();
    }

    /**
     *
     * @return: object form color type that multiply by Ka.
     */

    public Color getIntensity()
    {
        return new Color((int)(_color.getRed() * _Ka),
                (int)(_color.getGreen() * _Ka),
                (int)(_color.getBlue() * _Ka));
    }

    @Override
    public Vector getL(Point3D point) {
        return null;
    }
}
