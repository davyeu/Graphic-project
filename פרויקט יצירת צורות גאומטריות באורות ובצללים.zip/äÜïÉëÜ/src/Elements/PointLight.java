package Elements;

import primitives.Point3D;
import primitives.Vector;

import java.awt.*;

public class PointLight extends Light implements LightSource {

    Point3D _position;
    double _Kc, _Kl, _Kq;

    // ***************** Constructors **********************

    /**
     *
     * @param color- the source of light (namely r.g.b color)
     * @param position- another source of light (not the mainly source) that illuminate from this point.
     * @param kc- decreased factor
     * @param kl -decreased factor
     * @param kq -decreased factor
     *
     * @meaning: the function illuminated a point on a geometry shape.
     * the doubles "kc,kl,kq" are factor that decrease the illumination by the pong formula.
     */
    public PointLight(Color color, Point3D position,double kc, double kl, double kq)
    {
           super(color);
            _position=position;
            _Kc=kc;
            _Kl=kl;
            _Kq=kq;

    }

    // ***************** Getters/Setters **********************

    /**
     *
     * @param point - a point of the geometry shape
     * @return - the color of the point
     *
     * @meaning: the function illuminated a point on a geometry shape.
     * the doubles "kc,kl,kq" are factor that decrease the illumination by the pong formula.
     */
    @Override
    public Color getIntensity(Point3D point)
    {


            int r = _color.getRed();
            int g = _color.getGreen();
            int b = _color.getBlue();

            double d = _position.distance(point);

            double k = 1/(_Kc + _Kl*d + _Kq*Math.pow(d, 2));

            if (k > 1) k = 1;

            return new Color((int)(r * k),
                    (int)(g * k),
                    (int)(b * k));

    }

    /**
     *
     * @param point- a point of the geometry shape
     * @return- the vector from the secondary source of light to the point
     */
    public Vector getL(Point3D point)
    {
        return new Vector(_position,point);
    }

}
