package Elements;


import primitives.Point3D;
import primitives.Vector;

import java.awt.*;


public class DirectionalLight extends Light implements LightSource {

    private Vector _direction;

// ***************** Constructors **********************

    /**
     *
     * @param color- the source of light (namely r.g.b color)
     * @param direction- the direction of the source of the light
     */
    public DirectionalLight(Color color, Vector direction)
    {
        super (color);
        _direction = new Vector(direction);
    }


    // ***************** Getters/Setters **********************

    /**
     *
     * @param point- a point on the geometry
     * @return  = the intensity of the light
     */
    public Color getIntensity(Point3D point)
    {
        return getIntensity();
    }
    public Vector getDirection()
    {
        return new Vector(_direction);
    }
    public void setDirection(Vector direction)
    {
        direction=_direction;
    }

    /**
     *
     * @param point- a point on the geometry
     * @return- the vector from the source of light to the point.
     */
    public Vector getL(Point3D point)
    {
        return new Vector(point); //changed
    }

}
