package primitives;

import org.junit.Test;
import static org.junit.Assert.*;

public class Point3DTest {
    @Test
    public void testcomperTo()
    {
        System.out.println("compareTo test");
        Point3D testComper = new Point3D();
        int result = testComper.compareTo(new Point3D(0, 0, 0));
        assertEquals(0, result);

        Point3D p1 = new Point3D(1, 2, 3);
        Point3D p2 = new Point3D(8, 5, 2);
        assertEquals(p1.compareTo(p2), 1);

    }

    @Test
    public void testadd()
    {

        System.out.println("add test");//???
        Point3D p1=new Point3D(1,2,3);
        //Vector vec= ;
        p1.add(new Vector(1,1,1));
        Point3D p2= new Point3D(2,3,4);
        assertEquals(p1.compareTo(p2),0);
    }
    @Test
    public void testString()
    {
        System.out.println("string test");
        Point3D p1= new Point3D(1,2,3);
        assertEquals (p1.toString(),"(1.00, 2.00, 3.00)");

    }
    @Test
    public void testsubstract()
    {
        System.out.println("substract test");
        Point3D p1=new Point3D(1,5,6);
        p1.subtract(new Vector(2,4,6));
        assertEquals(p1.compareTo(new Point3D(-1,1,0)),0);
    }
    @Test
    public void testDistance() {
        System.out.println("distance test");
        Point3D p1 = new Point3D(1, 3, 2);
        Point3D p2 = new Point3D(1, 3, 4);
        assertEquals(p1.distance(p2), 2, 0);
    }
}
