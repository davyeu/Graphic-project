package primitives;

import org.junit.Test;

import static org.junit.Assert.*;

public class VectorTest {

    @Test
    public void testAdd()
    {
        Vector vec1= new Vector (1,2,3);
        Vector vec2= new Vector (1,1,1);
        Vector vec3= new Vector (2,3,4);
        vec1.add(vec2);
        assertEquals(vec1.compareTo(vec3),0);
    }

    @Test
    public void substructTest()
    {
        Vector vec1= new Vector (1,2,3);
        Vector vec2= new Vector (1,1,1);
        Vector vec3= new Vector (0,1,2);
        vec1.subtract(vec2);
        assertEquals(vec1.compareTo(vec3),0);
    }

    @Test
    public void ScalingTest()
    {
        Vector vec1= new Vector (1,2,3);
        vec1.scale(2);
        Vector vec2= new Vector (2,4,6);
        assertEquals(vec1.compareTo(vec2),0);
    }

    @Test
    public void DotProductTest()
    {
        Vector vec1= new Vector (1,2,3);
        double temp= 14;
        double epsilon=0.0;
        assertEquals(vec1.dotProduct(vec1),temp,epsilon);

    }

    @Test
    public void LengthTest()
    {
        Vector vec1= new Vector (2,2,1);
        double temp=3;
        double epsilon=0.0;
        assertEquals(vec1.length(),temp,epsilon);
    }

    @Test
    public void NormalizeTest()
    {
        Vector vec1= new Vector (2,2,1);
        double temp=1;
        double epsilon=0.0;
        vec1.normalize();
        assertEquals(vec1.length(),temp,epsilon);
    }

    @Test
    public void CrossProductTest()
    {
        Vector vec1= new Vector (1,2,3);
        Vector vec2= new Vector (4,5,6);
        Vector vec3= new Vector(-3,6,-3);
        Vector vec4=vec1.crossProduct(vec2);
        assertEquals(vec4.compareTo(vec3),0);
    }
}