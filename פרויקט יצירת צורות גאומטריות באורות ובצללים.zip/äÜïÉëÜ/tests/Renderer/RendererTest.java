package Renderer;

import static org.junit.Assert.*;

import Elements.*;
import Geometries.Plane;
import org.junit.Test;

import Geometries.Sphere;
import Geometries.Triangle;
import primitives.Material;
import primitives.Point3D;
import Renderer.ImageWriter;
import Renderer.Renderer;
import Scene.Scene;
import primitives.Vector;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class RendererTest {

    @Test
    public void basicRendering() {

        Scene scene = new Scene();

        scene.addGeometry(new Sphere(50, new Point3D(0.0, 0.0, -150)));

        Triangle triangle = new Triangle(new Point3D(100, 0, -149),
                new Point3D(0, 100, -149),
                new Point3D(100, 100, -149));

        Triangle triangle2 = new Triangle(new Point3D(100, 0, -149),
                new Point3D(0, -100, -149),
                new Point3D(100, -100, -149));

        Triangle triangle3 = new Triangle(new Point3D(-100, 0, -149),
                new Point3D(0, 100, -149),
                new Point3D(-100, 100, -149));

        Triangle triangle4 = new Triangle(new Point3D(-100, 0, -149),
                new Point3D(0, -100, -149),
                new Point3D(-100, -100, -149));

        scene.addGeometry(triangle);
        scene.addGeometry(triangle2);
        scene.addGeometry(triangle3);
        scene.addGeometry(triangle4);

        ImageWriter imageWriter = new ImageWriter("Render test", 500, 500, 500, 500);

        Renderer render = new Renderer(imageWriter, scene);

        render.renderImage();
        render.printGrid(50);
        render.writeToImage();

    }

    @Test
    public void emmissionTest() {
        Scene scene = new Scene();
        scene.setScreenDistance(50);

        Sphere sphere = new Sphere(50, new Point3D(0.0, 0.0, -55));
        Triangle triangle1 = new Triangle(new Point3D(150, 0, -50),
                new Point3D(0, 150, -50),
                new Point3D(150, 150, -50));

        Triangle triangle2 = new Triangle(new Point3D(150, 0, -50),
                new Point3D(0, -150, -50),
                new Point3D(150, -150, -50));

        Triangle triangle3 = new Triangle(new Point3D(-150, 0, -50),
                new Point3D(0, 150, -50),
                new Point3D(-150, 150, -50));

        Triangle triangle4 = new Triangle(new Point3D(-150, 0, -50),
                new Point3D(0, -150, -50),
                new Point3D(-150, -150, -50));

        sphere.setEmmission(new Color(255, 255, 0));
        triangle1.setEmmission(new Color(255, 0, 0));
        triangle2.setEmmission(new Color(0, 255, 0));
        triangle3.setEmmission(new Color(0, 0, 255));
        triangle4.setEmmission(new Color(0, 255, 255));

        scene.addGeometry(sphere);
        scene.addGeometry(triangle1);
        scene.addGeometry(triangle2);
        scene.addGeometry(triangle3);
        scene.addGeometry(triangle4);

        ImageWriter imageWriter = new ImageWriter("Emmission test", 500, 500, 500, 500);

        Renderer render = new Renderer(imageWriter, scene);

        render.renderImage();
        render.printGrid(50);
        render.writeToImage();
    }


    @Test
    public void emmissionTest1() throws Exception {
        Scene scene = new Scene();
        scene.setScreenDistance(50);

        Sphere sphere = new Sphere(50, new Point3D(0.0, 0.0, -55));
        Triangle triangle = new Triangle(new Point3D(150, 0, -55),
                new Point3D(0, 150, -55),
                new Point3D(150, 150, -55));

        Triangle triangle2 = new Triangle(new Point3D(150, 0, -55),
                new Point3D(0, -150, -55),
                new Point3D(150, -150, -55));

        Triangle triangle3 = new Triangle(new Point3D(-150, 0, -55),
                new Point3D(0, 150, -55),
                new Point3D(-150, 150, -55));

        Triangle triangle4 = new Triangle(new Point3D(-150, 0, -55),
                new Point3D(0, -150, -55),
                new Point3D(-150, -150, -55));

        sphere.setEmmission(new Color(255, 255, 0));
        triangle.setEmmission(new Color(255, 0, 0));
        triangle2.setEmmission(new Color(0, 255, 0));
        triangle3.setEmmission(new Color(0, 0, 255));
        triangle4.setEmmission(new Color(0, 255, 255));

        scene.addGeometry(sphere);
        scene.addGeometry(triangle);
        scene.addGeometry(triangle2);
        scene.addGeometry(triangle3);
        scene.addGeometry(triangle4);

        ImageWriter imageWriter = new ImageWriter("Emmission test1", 500, 500, 500, 500);

        Renderer render = new Renderer(imageWriter, scene);

        render.renderImage();
        render.printGrid(50);
        render.writeToImage();
    }

        @Test
        public void spotLightTest () {

            Scene scene = new Scene();
            Sphere sphere = new Sphere(800, new Point3D(0.0, 0.0, -1000));
            sphere.setShininess(20);
            sphere.setEmmission(new Color(0, 0, 100));
            scene.addGeometry(sphere);
            scene.addLight(new SpotLight(new Color(100, 100, 100), new Point3D(500, -200, -100),
                    new Vector(2, 2, -3), 0, 0.00001, 0.000005));
            ImageWriter imageWriter = new ImageWriter("Spot test", 500, 500, 500, 500);
            Renderer render = new Renderer(imageWriter, scene);
            render.renderImage();
            render.writeToImage();

        }
        @Test
        public void spotLightTest3 () {

            Scene scene = new Scene();

            Triangle triangle = new Triangle(new Point3D(3500, 3500, -2000),
                    new Point3D(-3500, -3500, -1000),
                    new Point3D(3500, -3500, -2000));

            Triangle triangle2 = new Triangle(new Point3D(3500, 3500, -2000),
                    new Point3D(-3500, 3500, -1000),
                    new Point3D(-3500, -3500, -1000));

            scene.addGeometry(triangle);
            scene.addGeometry(triangle2);

            scene.addLight(new SpotLight(new Color(255, 100, 100), new Point3D(200, 200, -100),
                    new Vector(-2, -2, -3),
                    0, 0.000001, 0.0000005));


            ImageWriter imageWriter = new ImageWriter("Spot test 3", 500, 500, 500, 500);

            Renderer render = new Renderer(imageWriter, scene);

            render.renderImage();
            render.writeToImage();

        }
        @Test
        public void spotLightTest2 () {

            Scene scene = new Scene();
            scene.setScreenDistance(200);
            scene.getCamera().set_vUp(new Vector(0, 1, 0));
            Sphere sphere = new Sphere(500, new Point3D(0.0, 0.0, -1000));
            sphere.setShininess(20);
            sphere.setEmmission(new Color(0, 0, 100));
            scene.addGeometry(sphere);

            Triangle triangle = new Triangle(new Point3D(-125, -225, -260),
                    new Point3D(-225, -125, -260),
                    new Point3D(-225, -225, -270));

            triangle.setEmmission(new Color(0, 0, 100));
            triangle.setShininess(4);
            scene.addGeometry(triangle);
            scene.addLight(new SpotLight(new Color(255, 100, 100), new Point3D(-200, -200, -150),
                    new Vector(2, 2, -3),
                    0.1, 0.00001, 0.000005));

            ImageWriter imageWriter = new ImageWriter("Spot test 2", 500, 500, 500, 500);

            Renderer render = new Renderer(imageWriter, scene);

            render.renderImage();
            render.writeToImage();

        }

        @Test
        public void shadowTest1 () {
            //Scene
            Scene scene = new Scene();
            scene.setCamera(new Camera(new Point3D(50.0, 20.0, 30), new Vector(0.0, 1.0, 0.0), new Vector(0.0, 0.0, -1.0)));
            scene.setScreenDistance(150);
            scene.setBackground(new Color(0, 0, 0));
            scene.setAmbientLight(new AmbientLight());
            //Sphere1
            Sphere sphere1 = new Sphere(10, new Point3D(30, -20, -40));
            sphere1.setEmmission(new Color(108, 0, 21));
            sphere1.setMaterial(new Material());
            //Sphere2
            Sphere sphere2 = new Sphere(10, new Point3D(-30, -20, -40));
            sphere2.setEmmission(new Color(0, 9, 108));
            sphere2.setMaterial(new Material());

            //Plane
            Plane plane = new Plane(new Vector(0, 50, 0), new Point3D(0, -30, 0));
            plane.setEmmission(new Color(28, 75, 14));
            plane.setMaterial(new Material());


            //Light Sources
            List<LightSource> lights = new ArrayList<LightSource>();
            PointLight pointLight1 = new PointLight(new Color(255, 252, 145), new Point3D(20, 20, -40), 0.1, 0.01, 0.001);
            PointLight pointLight = new PointLight(new Color(255, 252, 145),
                    new Point3D(0, 15, -40), 0.1, 0.01, 0.001);

            //Add To Scene
            scene.addGeometry(sphere1);
            scene.addGeometry(sphere2);
            scene.addGeometry(plane);
            //  scene.addLight(pointLight);
            scene.addLight(pointLight1);


            //Render Image


            ImageWriter imageWriter = new ImageWriter("ShadowTest1", 501, 501, 500, 500);
            Renderer render = new Renderer(imageWriter, scene);
            render.renderImage();
            //render.renderImage();
            render.writeToImage();
        }

    }


